SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `banners`;

DROP TABLE IF EXISTS `banner_details`;

SET foreign_key_checks = 1;
