DROP VIEW IF EXISTS `user_leave_authorities_view`;
DROP VIEW IF EXISTS `holidays_view`;
DROP VIEW IF EXISTS `user_leaves_view`;
DROP VIEW IF EXISTS `leave_applications_view`;
DROP VIEW IF EXISTS `leave_reasons_view`;
DROP VIEW IF EXISTS `leave_types_view`;