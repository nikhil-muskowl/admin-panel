SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `holidays`;

DROP TABLE IF EXISTS `holiday_details`;

DROP TABLE IF EXISTS `user_leaves`;

DROP TABLE IF EXISTS `leave_applications`;

DROP TABLE IF EXISTS `leave_reasons`;

DROP TABLE IF EXISTS `leave_reason_details`;

DROP TABLE IF EXISTS `leave_statuses`;

DROP TABLE IF EXISTS `leave_status_details`;

DROP TABLE IF EXISTS `leave_types`;

DROP TABLE IF EXISTS `leave_type_details`;

DROP TABLE IF EXISTS `user_leave_authorities`;

SET foreign_key_checks = 1;
