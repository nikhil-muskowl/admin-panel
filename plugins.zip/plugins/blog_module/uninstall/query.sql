SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `blogs`;

DROP TABLE IF EXISTS `blog_details`;

DROP TABLE IF EXISTS `blog_images`;

DROP TABLE IF EXISTS `blog_rankings`;

DROP TABLE IF EXISTS `blog_tags`;

DROP TABLE IF EXISTS `blog_to_types`;

DROP TABLE IF EXISTS `blog_types`;

DROP TABLE IF EXISTS `blog_type_details`;

SET foreign_key_checks = 1;
