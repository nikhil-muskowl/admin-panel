DROP VIEW IF EXISTS `blogs_view`;
DROP VIEW IF EXISTS `blog_types_view`;