SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `stories`;

DROP TABLE IF EXISTS `story_comments`;

DROP TABLE IF EXISTS `story_complains`;

DROP TABLE IF EXISTS `story_details`;

DROP TABLE IF EXISTS `story_images`;

DROP TABLE IF EXISTS `story_image_details`;

DROP TABLE IF EXISTS `story_rankings`;

DROP TABLE IF EXISTS `story_tags`;

DROP TABLE IF EXISTS `story_to_types`;

DROP TABLE IF EXISTS `story_types`;

DROP TABLE IF EXISTS `story_type_details`;

DROP TABLE IF EXISTS `save_stories`;

SET foreign_key_checks = 1;
