DROP VIEW IF EXISTS `stories_view`;
DROP VIEW IF EXISTS `story_types_view`;
DROP VIEW IF EXISTS `story_comments_view`;
DROP VIEW IF EXISTS `story_complains_view`;