<?php

$lang['text_heading_list'] = 'story types list';
$lang['text_heading_form'] = 'story types';
