<?php

$lang['text_heading_list'] = 'story comments list';
$lang['text_heading_form'] = 'story comments';
$lang['text_user_name'] = 'user name';
$lang['text_comment'] = 'comment';
$lang['text_status'] = 'status';
$lang['text_date'] = 'date';
$lang['text_action'] = 'action';
