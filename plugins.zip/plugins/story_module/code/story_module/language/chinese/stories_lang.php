<?php

$lang['text_heading_list'] = 'story list';
$lang['text_heading_form'] = 'story';
$lang['text_title'] = 'title';
$lang['text_total_likes'] = 'total likes';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';