<?php

$lang['text_heading_list'] = 'story complains list';
$lang['text_heading_form'] = 'story complains';
$lang['text_title'] = 'title';
$lang['text_story_title'] = 'story title';
$lang['text_comment'] = 'comment';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';
