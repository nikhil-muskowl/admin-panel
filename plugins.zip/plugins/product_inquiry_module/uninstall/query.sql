SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `p_inquiries`;

DROP TABLE IF EXISTS `p_inquiry_to_types`;

DROP TABLE IF EXISTS `p_inquiry_types`;

DROP TABLE IF EXISTS `p_inquiry_type_details`;

SET foreign_key_checks = 1;
