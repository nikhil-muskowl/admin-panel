DROP VIEW IF EXISTS `p_inquiry_types_view`;
DROP VIEW IF EXISTS `p_inquiries_view`;