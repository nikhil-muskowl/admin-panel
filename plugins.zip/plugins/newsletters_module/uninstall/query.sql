SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `newsletters`;

DROP TABLE IF EXISTS `newsletter_mails`;

DROP TABLE IF EXISTS `newsletter_mail_trackers`;

SET foreign_key_checks = 1;
