SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `user_activities`;

SET foreign_key_checks = 1;
