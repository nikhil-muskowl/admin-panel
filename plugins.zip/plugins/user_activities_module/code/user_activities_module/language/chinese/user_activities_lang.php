<?php

$lang['text_heading_list'] = 'user activities list';
$lang['text_heading_form'] = 'user activities';
$lang['text_user_name'] = 'user name';
$lang['text_text'] = 'activity';
