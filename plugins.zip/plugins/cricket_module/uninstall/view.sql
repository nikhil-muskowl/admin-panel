DROP VIEW IF EXISTS `cricket_battings_view`;
DROP VIEW IF EXISTS `cricket_bowllings_view`;
DROP VIEW IF EXISTS `cricket_players_view`;
DROP VIEW IF EXISTS `cricket_team_matches_view`;
DROP VIEW IF EXISTS `cricket_team_points_view`;
DROP VIEW IF EXISTS `cricket_player_roles_view`;
DROP VIEW IF EXISTS `cricket_player_levels_view`;