DROP VIEW IF EXISTS `advertisements_view`;
DROP VIEW IF EXISTS `advertisement_types_view`;