SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `advertisements`;

DROP TABLE IF EXISTS `advertisement_details`;

DROP TABLE IF EXISTS `advertisement_images`;

DROP TABLE IF EXISTS `advertisement_tags`;

DROP TABLE IF EXISTS `advertisement_to_types`;

DROP TABLE IF EXISTS `advertisement_types`;

DROP TABLE IF EXISTS `advertisement_type_details`;

SET foreign_key_checks = 1;
