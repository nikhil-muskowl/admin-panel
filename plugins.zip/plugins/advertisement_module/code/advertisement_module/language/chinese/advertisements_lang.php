<?php

$lang['text_heading_list'] = 'blog list';
$lang['text_heading_form'] = 'blog';
