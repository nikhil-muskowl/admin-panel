<?php

$lang['text_heading_list'] = 'testimonials list';
$lang['text_heading_form'] = 'testimonial';
$lang['text_author'] = 'author';
$lang['text_role'] = 'role';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';
