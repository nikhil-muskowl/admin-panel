<?php

$lang['text_heading_list'] = 'testimonials list';
$lang['text_heading_form'] = 'testimonial';
$lang['text_author'] = 'author';
$lang['text_role'] = 'role';
$lang['text_image'] = 'image';
$lang['text_text'] = 'text';
$lang['text_language'] = 'language';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';
