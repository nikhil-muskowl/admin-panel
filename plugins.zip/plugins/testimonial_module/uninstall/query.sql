SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `testimonials`;

SET foreign_key_checks = 1;
