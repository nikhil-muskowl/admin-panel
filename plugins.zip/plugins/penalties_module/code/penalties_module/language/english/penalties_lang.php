<?php

$lang['text_heading_list'] = 'penalty applications list';
$lang['text_heading_form'] = 'penalty application';
$lang['text_user'] = 'user';
$lang['text_penalty_reason'] = 'penalty reason';
$lang['text_date'] = 'date';
$lang['text_total'] = 'total';
$lang['text_subject'] = 'subject';
$lang['text_text'] = 'text';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';
