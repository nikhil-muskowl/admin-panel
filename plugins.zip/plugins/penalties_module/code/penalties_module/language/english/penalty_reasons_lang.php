<?php

$lang['text_heading_list'] = 'penalty reasons list';
$lang['text_heading_form'] = 'penalty reason';
$lang['text_title'] = 'title';
$lang['text_date'] = 'date';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';