DROP VIEW IF EXISTS `penalty_reasons_view`;
DROP VIEW IF EXISTS `penalties_view`;