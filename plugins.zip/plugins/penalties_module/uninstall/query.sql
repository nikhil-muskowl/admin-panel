SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `penalties`;

DROP TABLE IF EXISTS `penalty_reasons`;

DROP TABLE IF EXISTS `penalty_reason_details`;

SET foreign_key_checks = 1;
