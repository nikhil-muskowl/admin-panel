SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `inquiries`;

DROP TABLE IF EXISTS `inquiry_to_types`;

DROP TABLE IF EXISTS `inquiry_types`;

DROP TABLE IF EXISTS `inquiry_type_details`;

SET foreign_key_checks = 1;
