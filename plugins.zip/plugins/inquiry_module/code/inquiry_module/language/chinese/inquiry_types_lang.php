<?php

$lang['text_heading_list'] = 'Inquiry Types List';
$lang['text_heading_form'] = 'Inquiry Types Form';
