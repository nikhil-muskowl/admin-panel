<?php

$lang['text_heading_list'] = 'Inquiries list';
$lang['text_heading_form'] = 'Inquiries';


$lang['text_inquiry'] = 'Inquiry';





