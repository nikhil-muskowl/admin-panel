SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `pets`;

DROP TABLE IF EXISTS `pet_details`;

DROP TABLE IF EXISTS `pet_levels`;

DROP TABLE IF EXISTS `user_pets`;

DROP TABLE IF EXISTS `user_pet_points`;

SET foreign_key_checks = 1;
