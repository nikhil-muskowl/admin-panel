DROP VIEW IF EXISTS `pets_view`;
DROP VIEW IF EXISTS `user_pets_view`;
DROP VIEW IF EXISTS `pet_levels_view`;
DROP VIEW IF EXISTS `user_pet_points_view`;