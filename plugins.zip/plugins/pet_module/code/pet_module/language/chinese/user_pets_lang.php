<?php

$lang['text_heading_list'] = 'user pets list';
$lang['text_heading_form'] = 'user pet';
$lang['text_image'] = 'image';
$lang['text_user'] = 'user';
$lang['text_pet'] = 'pet';
$lang['text_level'] = 'level';
