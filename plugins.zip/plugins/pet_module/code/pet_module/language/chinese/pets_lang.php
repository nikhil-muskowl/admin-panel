<?php

$lang['text_heading_list'] = 'pets list';
$lang['text_heading_form'] = 'pet';
