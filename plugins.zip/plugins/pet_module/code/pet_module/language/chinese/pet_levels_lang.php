<?php

$lang['text_heading_list'] = 'pet levels list';
$lang['text_heading_form'] = 'pet level';
$lang['text_image'] = 'image';
$lang['text_title'] = 'pet name';
$lang['text_level'] = 'level';
$lang['text_points'] = 'points';
