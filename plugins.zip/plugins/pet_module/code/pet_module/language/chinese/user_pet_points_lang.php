<?php

$lang['text_heading_list'] = 'user points list';
$lang['text_heading_form'] = 'user points';
$lang['text_user_image'] = 'user image';
$lang['text_user_email'] = 'user email';
$lang['text_user_name'] = 'user name';
$lang['text_points'] = 'points';
$lang['text_description'] = 'description';
