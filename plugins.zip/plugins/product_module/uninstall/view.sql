DROP VIEW IF EXISTS `categories_view`;
DROP VIEW IF EXISTS `products_view`;
DROP VIEW IF EXISTS `attribute_groups_view`;
DROP VIEW IF EXISTS `attributes_view`;
DROP VIEW IF EXISTS `product_attributes_view`;
DROP VIEW IF EXISTS `product_wishlists_view`;
DROP VIEW IF EXISTS `product_ratings_view`;
DROP VIEW IF EXISTS `product_reviews_view`;