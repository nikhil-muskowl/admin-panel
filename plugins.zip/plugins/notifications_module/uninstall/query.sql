SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `notifications`;

DROP TABLE IF EXISTS `notification_details`;

DROP TABLE IF EXISTS `notification_to_users`;

SET foreign_key_checks = 1;
