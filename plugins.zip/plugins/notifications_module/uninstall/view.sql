DROP VIEW IF EXISTS `notifications_view`;
DROP VIEW IF EXISTS `user_notifications_view`;