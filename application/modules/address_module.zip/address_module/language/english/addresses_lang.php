<?php

$lang['text_heading_list'] = 'addresses list';
$lang['text_heading_form'] = 'addresses';
$lang['text_user'] = 'user';
$lang['text_country'] = 'country';
$lang['text_zone'] = 'zone';
$lang['text_name'] = 'name';

$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';

