<?php

$lang['text_heading_list'] = 'countries list';
$lang['text_heading_form'] = 'countries';
$lang['text_name'] = 'name';
$lang['text_iso_code_2'] = 'iso code 2';
$lang['text_iso_code_3'] = 'iso code 3';
$lang['text_address_format'] = 'address format';
$lang['text_postcode_required'] = 'postcode required';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';

