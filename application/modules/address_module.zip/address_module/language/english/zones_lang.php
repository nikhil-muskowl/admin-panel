<?php

$lang['text_heading_list'] = 'zones list';
$lang['text_heading_form'] = 'zones';
$lang['text_country'] = 'country';
$lang['text_name'] = 'name';
$lang['text_code'] = 'code';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';

