<?php

$lang['text_heading_list'] = 'Leave applications list';
$lang['text_heading_form'] = 'Leave application';
$lang['text_user'] = 'user';
$lang['text_from_date'] = 'from date';
$lang['text_to_date'] = 'to date';
$lang['text_total'] = 'total';
$lang['text_leave_status'] = 'leave status';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';
