<?php

$lang['text_heading_list'] = 'user leave authorities list';
$lang['text_heading_form'] = 'user leave authorities';
$lang['text_user'] = 'user';
$lang['text_author'] = 'author';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';