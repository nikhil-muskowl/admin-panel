<?php

$lang['text_heading_list'] = 'user leaves list';
$lang['text_heading_form'] = 'user leave';
$lang['text_user'] = 'user';
$lang['text_leave_type'] = 'leave type';
$lang['text_total'] = 'total';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';