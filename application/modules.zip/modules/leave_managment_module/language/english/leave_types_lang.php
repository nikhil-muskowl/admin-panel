<?php

$lang['text_heading_list'] = 'leave types list';
$lang['text_heading_form'] = 'leave type';
$lang['text_title'] = 'title';
$lang['text_type'] = 'type';
$lang['text_value'] = 'value';
$lang['text_file'] = 'file';
$lang['text_date'] = 'date';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';
