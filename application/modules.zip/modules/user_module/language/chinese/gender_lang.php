<?php

$lang['text_heading_list'] = 'genders list';
$lang['text_heading_form'] = 'gender';
