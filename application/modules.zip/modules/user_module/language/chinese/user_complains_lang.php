<?php

$lang['text_heading_list'] = 'user complains list';
$lang['text_heading_form'] = 'user complains';
$lang['text_title'] = 'title';
$lang['text_user_name'] = 'user name';
$lang['text_complain_by'] = 'complain by';
$lang['text_status'] = 'status';
$lang['text_modified_date'] = 'modified date';
$lang['text_action'] = 'action';