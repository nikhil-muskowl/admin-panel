<?php

$lang['text_heading_list'] = 'users list';
$lang['text_heading_form'] = 'user';
$lang['text_user_group'] = 'user group';
$lang['text_admin'] = 'admin';
$lang['text_verified'] = 'verified';
