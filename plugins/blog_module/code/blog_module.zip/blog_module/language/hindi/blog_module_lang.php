<?php

$lang['text_heading_list'] = 'लिंग सूची';
$lang['text_heading_form'] = 'लिंग';
